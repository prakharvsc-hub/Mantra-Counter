# Spiritual Chanting Counter - Android WebView APK Wrapper

This is a complete, compile-ready Android Studio project that wraps the Sacred Spiritual Chanting Counter inside a high-performance native Android WebView with full hardware bridge integration.

## Features Wrapped in Android Native:
- **Local Asset Execution**: Bundled in `app/src/main/assets/index.html`, runs 100% offline without internet.
- **Native Haptics**: Uses Android `Vibrator` / `VibratorManager` via `AndroidBridge.vibrate()` for crisp haptic feedback.
- **Mala Completion Chime**: Web Audio API sacred Tibetan harmonic chime and vibrational pulses.
- **Screen Wake Lock**: Android `FLAG_KEEP_SCREEN_ON` prevents screen from turning off while chanting.
- **Immersive Fullscreen Mode**: Auto-hides system status bar and navigation bars for prayer focus.
- **Back Navigation**: Hardware back button handled safely.

---

## 🚀 How to Build the APK

### Method 1: Android Studio (Easiest & Recommended)
1. Download and extract this project zip.
2. Open **Android Studio** (Hedgehog or newer recommended).
3. Select **File > Open...** and choose this project folder.
4. Allow Gradle sync to finish (takes ~30-60 seconds on first run).
5. In the top menu, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When compilation finishes, click **locate** in the popup notification to get your `app-debug.apk`!
7. Copy the `app-debug.apk` to your Android phone and install!

### Method 2: Command Line (CLI)
Make sure you have JDK 17 installed:
```bash
# Build the debug APK
./gradlew assembleDebug

# Output APK path:
# app/build/outputs/apk/debug/app-debug.apk
```

To install directly to a connected Android phone with USB debugging enabled:
```bash
./gradlew installDebug
```

### Method 3: Automated Free GitHub Actions (Zero Local Setup)
1. Push this project to a GitHub repository.
2. The included `.github/workflows/build-apk.yml` will automatically trigger.
3. Go to the **Actions** tab on your GitHub repository.
4. Download the ready-to-install APK artifact directly from your browser!

---

*Made with devotion for Spiritual Chanting Counter (Original counter by Prakhar)*
